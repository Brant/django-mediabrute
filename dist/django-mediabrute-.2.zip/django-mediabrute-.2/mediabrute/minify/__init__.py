"""
Minify scripts

These are NOT my minifiers
"""
from cssmin import cssmin
from js_min import jsmin