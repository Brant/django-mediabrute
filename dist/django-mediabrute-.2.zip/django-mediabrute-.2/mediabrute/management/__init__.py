"""
Custom management tools for Django
"""