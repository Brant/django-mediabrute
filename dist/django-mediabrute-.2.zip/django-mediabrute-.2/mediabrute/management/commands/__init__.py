"""
Custom commands for Django's manage.py
"""