"""
This file is requires for Django compatibility only, this module provides no models.
"""


